size_t WiFiClient::write_P(PGM_P buf, size_t size)
is not buffered, it just blocks if needed

